package sample;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class StartTaskController  implements Initializable {
    @FXML
    private Label TitleShowLable;

    @FXML
    private Label TypeShowLable;
    ProgramController programController;
    Task task;
    boolean done=false;
    String query;
    Connection connection;
    Statement statement;
    public StartTaskController()
    {
        TitleShowLable=new Label();
        TypeShowLable=new Label();
        programController=new ProgramController();
        task=programController.getSelectionTask();

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        TitleShowLable.setText(task.getTitle());
        TypeShowLable.setText(task.getType());
        programController.draw(task.getHours(),task.getMinutes());
        query="select * from TaskTable";
        try {
            connection= DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Elite\\Desktop\\TasksManagement.accdb");
            statement= connection.createStatement();
            ResultSet resultSet=statement.executeQuery(query);
            while (resultSet.next()){
                programController.addTask(resultSet.getString("Title"),resultSet.getString("Type"),resultSet.getInt("Hours"),resultSet.getInt("Minutes"));
            }
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void stopTimer()
    {
        programController.stopTimer();
    }
    public void continueTimer()
    {
        programController.continueTimer();
    }
    public void Done()
    {
        programController.setDoTasks(task);
        programController.setRestTasks(task);
        done=true;
        programController.stopTimer();
    }
    public void UnDone()
    {
        if(!done) {
            programController.setUnDoTasks(task);
            programController.setRestTasks(task);
            programController.stopTimer();

        }
    }
}
