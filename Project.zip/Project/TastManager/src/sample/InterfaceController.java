package sample;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class InterfaceController {
        Sleep sleep;
    {
        new Sleep().start();
    }
}
class Sleep extends Thread{
    public void run()
    {
        try {
            Thread.sleep(2000);
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    try {
                        FXMLLoader fxmlLoader=new FXMLLoader(getClass().getResource("Login.fxml"));
                        Parent root1;
                        root1 = (Parent) fxmlLoader.load();
                        Stage stage=new Stage();
                        stage.setTitle("log in");
                        stage.setScene(new Scene(root1));
                        stage.setResizable(false);
                        stage.show();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
