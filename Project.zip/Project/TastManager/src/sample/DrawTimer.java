package sample;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
public class DrawTimer extends Task {
    JFrame frame;
    JLabel label;
    Font font;
    Timer timer;
    String doubleSecondFormat,doubleMinuteFormat;
    DecimalFormat decimalFormat=new DecimalFormat("00");
    public DrawTimer(int hour, int minute)
    {
        super(hour,minute);
        frame=new JFrame();
        frame.setSize(100,150);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
        label=new JLabel();
        label.setBounds(100,100,200,300);
        frame.add(label);
        doubleMinuteFormat=decimalFormat.format(DrawTimer.super.getMinutes());
        doubleSecondFormat=decimalFormat.format(DrawTimer.super.getSeconds());
        label.setText(hour+":"+doubleMinuteFormat+":"+doubleSecondFormat);
        font=new Font("Arial",Font.PLAIN,30);
        label.setFont(font);
        CountDownTimer();
        timer.start();
    }
    public void CountDownTimer()
    {
        timer=new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                DrawTimer.super.setSeconds(DrawTimer.super.getSeconds()-1);
                doubleMinuteFormat=decimalFormat.format(DrawTimer.super.getMinutes());
                doubleSecondFormat=decimalFormat.format(DrawTimer.super.getSeconds());
                label.setText(DrawTimer.super.getHours()+":"+doubleMinuteFormat+":"+doubleSecondFormat);
                if(DrawTimer.super.getSeconds()==-1)
                {
                    DrawTimer.super.setSeconds(59);
                    DrawTimer.super.setMinutes(DrawTimer.super.getMinutes()-1);
                    doubleMinuteFormat=decimalFormat.format(DrawTimer.super.getMinutes());
                    doubleSecondFormat=decimalFormat.format(DrawTimer.super.getSeconds());
                    label.setText(DrawTimer.super.getHours()+":"+doubleMinuteFormat+":"+doubleSecondFormat);
                }
                if(DrawTimer.super.getMinutes()==-1)
                {
                    DrawTimer.super.setMinutes(59);
                    DrawTimer.super.setHours(DrawTimer.super.getHours()-1);
                    doubleMinuteFormat=decimalFormat.format(DrawTimer.super.getMinutes());
                    doubleSecondFormat=decimalFormat.format(DrawTimer.super.getSeconds());
                    label.setText(DrawTimer.super.getHours()+":"+doubleMinuteFormat+":"+doubleSecondFormat);
                }
                if(DrawTimer.super.getHours()==0&& DrawTimer.super.getMinutes()==0&& DrawTimer.super.getSeconds()==0)
                {
                    timer.stop();
                }
            }
        });
    }
    public void stopTimer()
    {
        timer.stop();
    }
    public void Continue()
    {
        timer.start();
    }
}
