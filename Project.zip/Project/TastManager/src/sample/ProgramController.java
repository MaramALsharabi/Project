package sample;
import java.util.ArrayList;
public class ProgramController {
    private final int  limit;
    private  ArrayList<Task> alltasks;
    int sumMinutes=0;
    int sumHours=0;
    private  ArrayList<Task> UnDoTasks;
    private ArrayList doTasks;
    private ArrayList<Task>restTasks;
    Task task;
    static Task selectedTask;
    DrawTimer drawTimer;
    public ProgramController()
    {
        limit=24;    //24  hours
        alltasks=new ArrayList<Task>();
        doTasks=new ArrayList<>();
        UnDoTasks=new ArrayList<>();
        doTasks=new ArrayList<>();
        restTasks=alltasks;
    }
    public  boolean addTask(String title, String type, int time_Hour, int time_minute)
    {
        sumHours+=time_Hour;
        sumMinutes+=time_minute;
        while (sumMinutes>=60)
        {
            sumHours++;
            sumMinutes-=60;
        }
        if(sumHours>=limit) return false;
        else {
            task=new Task(title,type,time_Hour,time_minute);
            alltasks.add(task);
            return true;
        }}
        public boolean deleteTask(String title)
        {
            for (int i = 0; i < alltasks.size(); i++) {
                if (alltasks.get(i).getTitle()==title)
                {
                    alltasks.remove(i);
                    return true;
                }
            }

             return false;
        }

    public void setSelectionTask(Task task)
    {
        selectedTask=task;
    }
    public Task getSelectionTask()
    {
        return selectedTask;
    }

    public  boolean editTitle(Task t,String newTitle)
    {
        for (int i = 0; i < alltasks.size(); i++) {
            if(alltasks.get(i).getTitle().equals(t.getTitle()))
            {
                t.setTitle(newTitle);
                return true;
            }
        }
         return false;
    }
    public boolean editType(Task t,String newType)
    {
        for (int i = 0; i < alltasks.size(); i++) {
            if(alltasks.get(i).getTitle().equals(t.getTitle()))
            {
                t.setType(newType);
                return true;
            }
        }
        return false;
    }
    public boolean editHours(Task t, int newHours)
    {
        for (int i = 0; i < alltasks.size(); i++) {
            if(alltasks.get(i).getTitle()==t.getTitle())
            {
                sumHours-=t.getHours();
                sumHours+=newHours;
                if(sumHours>=limit)
                {
                    sumHours-=newHours;
                    sumHours+= t.getHours();
                    return false;
                }
                else t.setHours(newHours);
                return true;
            }
        }
        return false;
    }
    public boolean editMinutes(Task t, int newMinutes)
    {
        for (int i = 0; i < alltasks.size(); i++) {
            if(alltasks.get(i).getTitle()==t.getTitle())
            {
                sumMinutes-=t.getMinutes();
                sumMinutes+=newMinutes;
                while (sumMinutes>=60)
                {
                    sumHours++;
                    sumMinutes-=60;
                }
                if(sumHours<limit)
                {
                    t.setMinutes(newMinutes);
                    return true;
                }
                else
                {
                    sumMinutes+=t.getMinutes();
                    sumMinutes-=newMinutes;
                    return false;
                }
            }
        }
          return false;
    }

    public void setDoTasks(Task t)
{
     doTasks.add(t);
}
    public void setUnDoTasks(Task t)
    {
            UnDoTasks.add(t);
    }
    public void setRestTasks(Task t)
    {
        for (int i = 0; i <restTasks.size() ; i++) {
            if(restTasks.get(i)==t)
            {
                restTasks.remove(i);
            }

        }
    }
    public ArrayList<Task> getDoTasks()
    {
        return doTasks;
    }
    public ArrayList<Task> getUnDoTasks()
    {
        return UnDoTasks;
    }
    public ArrayList<Task> getRestTasks()
    {
        return restTasks;
    }
    public void draw(int hour, int minute)
{
     drawTimer=new DrawTimer(hour,minute);
}
    public void stopTimer()
{
    drawTimer.stopTimer();
}
    public void continueTimer()
    {
        drawTimer.Continue();
    }
}
