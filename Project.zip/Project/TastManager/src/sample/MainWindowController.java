package sample;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class MainWindowController {

    @FXML
    public void onAddButtonClick(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader=new FXMLLoader(getClass().getResource("Addition.fxml"));
            Parent root1;
            root1 = (Parent) fxmlLoader.load();
            Stage stage=new Stage();
            stage.setTitle("Addition");
            stage.setScene(new Scene(root1));
            stage.setResizable(false);
            stage.show();

        }catch (Exception e){
            System.out.println(0);
        }
    }

    @FXML
    public void viewTasksClick(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader=new FXMLLoader(getClass().getResource("ViewTasks.fxml"));
            Parent root1;
            root1 = (Parent) fxmlLoader.load();
            Stage stage=new Stage();
            stage.setTitle("Start doing Tasks");
            stage.setScene(new Scene(root1));
            stage.setResizable(false);
            stage.show();
        }catch (Exception e){
            System.out.println(0);
        }
    }
}
