package sample;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class ViewTasksController implements Initializable {

    @FXML private TableView<Task> viewTableTasks;
    @FXML private TableColumn<Task,String> titleColumn;
    @FXML private TableColumn<Task,String> typeColumn;
    @FXML private TableColumn<Task, Integer> hoursColumn;
    @FXML private TableColumn<Task, Integer> minutesColumn;
    @FXML
    private FontAwesomeIconView editIcon;
    @FXML
    private FontAwesomeIconView deleteIcon;
    @FXML
    private FontAwesomeIconView StartIcon;
    ObservableList<Task> tasksList;
    ProgramController programController;
    Connection connection;
    String query;
    Task task;
    MouseEvent event;
    Alert alert;
    public ViewTasksController()
    {
        tasksList= FXCollections.observableArrayList();
        programController=new ProgramController();
        event = null;
        viewTableTasks=new TableView<>();
        titleColumn=new TableColumn<>();
        typeColumn=new TableColumn<>();
        hoursColumn=new TableColumn<>();
        minutesColumn=new TableColumn<>();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            query="select * from TaskTable";
                connection= DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Elite\\Desktop\\TasksManagement.accdb");
                Statement statement= connection.createStatement();
                ResultSet resultSet=statement.executeQuery(query);
                while (resultSet.next()) {
                tasksList.add(new Task(resultSet.getString("Title"),resultSet.getString("Type"),resultSet.getInt("Hours"),resultSet.getInt("Minutes")));
                titleColumn.setCellValueFactory(new PropertyValueFactory<>("Title"));
                typeColumn.setCellValueFactory(new PropertyValueFactory<>("Type"));
                hoursColumn.setCellValueFactory(new PropertyValueFactory<>("Hours"));
                minutesColumn.setCellValueFactory(new PropertyValueFactory<>("Minutes"));
                viewTableTasks.setItems(tasksList);
                programController.addTask(resultSet.getString("Title"),resultSet.getString("Type"),resultSet.getInt("Hours"),resultSet.getInt("Minutes"));
            }
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
}
public void deleteMouseAction()
{
    deleteIcon.setOnMouseClicked((EventHandler<? super javafx.scene.input.MouseEvent>) event);
    {
        alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setContentText("Do want to delete this task ?");
        alert.showAndWait();
        if(alert.getResult().getText().equals("OK"))
        {
        query="DELETE FROM TaskTable WHERE (((TaskTable.Title)=\"";
            task=viewTableTasks.getSelectionModel().getSelectedItem();
            try {
            connection = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Elite\\Desktop\\TasksManagement.accdb");
            boolean deleted = programController.deleteTask(task.getTitle());
            PreparedStatement preparedStatement=connection.prepareStatement(query+task.getTitle()+"\"));");
            if(deleted){
                 alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText(null);
                alert.setContentText("successfully deleted");
                alert.showAndWait();            }
            else {
                 alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText(null);
                alert.setContentText("it has not been deleted");
                alert.showAndWait();
            }

            preparedStatement.execute();
            } catch (SQLException e) {
            e.printStackTrace();
        }}
    }
}
public void startDoingTask()
{
    StartIcon.setOnMouseClicked((EventHandler<? super javafx.scene.input.MouseEvent>) event);
    task=viewTableTasks.getSelectionModel().getSelectedItem();
    programController.setSelectionTask(task);
    try {

        FXMLLoader fxmlLoader=new FXMLLoader(getClass().getResource("StartTask.fxml"));
        Parent root1;
        root1 = (Parent) fxmlLoader.load();
        Stage stage=new Stage();
        stage.setTitle("Start Task");
        stage.setScene(new Scene(root1));
        stage.setResizable(false);
        stage.show();

    }catch (Exception e){
        e.printStackTrace();
    }
}
public void editTask()
{
    editIcon.setOnMouseClicked((EventHandler<? super javafx.scene.input.MouseEvent>) event);
    task=viewTableTasks.getSelectionModel().getSelectedItem();
    programController.setSelectionTask(task);
    try {
        FXMLLoader fxmlLoader=new FXMLLoader(getClass().getResource("EditTask.fxml"));
        Parent root1;
        root1 = (Parent) fxmlLoader.load();
        Stage stage=new Stage();
        stage.setTitle("Edition");
        stage.setScene(new Scene(root1));
        stage.setResizable(false);
        stage.show();

    }catch (Exception e){
        e.printStackTrace();
    }}
}

