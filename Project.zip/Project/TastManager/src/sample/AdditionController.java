package sample;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import java.sql.*;
public class AdditionController {
        @FXML
        private TextField textTitle;

        @FXML
        private TextField textHours;

        @FXML
        private TextField textType;

        @FXML
        private TextField textMinutes;
        ProgramController programController;
        String title;
        String type;
        int time_Hour;
        int time_minute;
        String query;
        Connection connection;
        Statement statement;
        public AdditionController() {
            programController=new ProgramController();
        }
        public void add() {
            query="select * from TaskTable";
            try {
                connection= DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Elite\\Desktop\\TasksManagement.accdb");
                statement= connection.createStatement();
                ResultSet resultSet=statement.executeQuery(query);
                while (resultSet.next()){
                    programController.addTask(resultSet.getString("Title"),resultSet.getString("Type"),resultSet.getInt("Hours"),resultSet.getInt("Minutes"));
                }
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            title = textTitle.getText();
            type = textType.getText();
            time_Hour = Integer.parseInt(textHours.getText());
            time_minute = Integer.parseInt(textMinutes.getText());
            String SHours=String.valueOf(time_Hour);
            String SMinutes=String.valueOf(time_Hour);
            if (title.isEmpty()||type.isEmpty()||SHours.isEmpty()||SMinutes.isEmpty())
            {
                Alert alert=new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText("please fill all data");
            }
            else {
                if(time_minute>60)
                {
                    Alert alert=new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("Sorry,you can't set minutes over 60 ");
                    alert.showAndWait();
                    System.out.println(programController.ViewTasks());
                }
                else{
            boolean added;
            added = programController.addTask(title, type, time_Hour, time_minute);
            if (added) {
                try {
                    Connection connection = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Elite\\Desktop\\TasksManagement.accdb");
                    PreparedStatement preparedStatement=connection.prepareStatement(" INSERT INTO TaskTable(Title,Type,Hours,Minutes) VALUES(?,?,?,?)");
                    preparedStatement.setString(1,textTitle.getText());
                    preparedStatement.setString(2,textType.getText());
                    preparedStatement.setInt(3, Integer.parseInt(textHours.getText()));
                    preparedStatement.setInt(4, Integer.parseInt(textMinutes.getText()));
                    preparedStatement.execute();
                    Alert alert=new Alert(Alert.AlertType.INFORMATION);
                    alert.setHeaderText(null);
                    alert.setContentText("successfully added");
                    alert.showAndWait();
                    textTitle.setText("");
                    textType.setText("");
                    textHours.setText("");
                    textMinutes.setText("");


                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText("not added");
                alert.showAndWait();
            }
        }}}

    }

