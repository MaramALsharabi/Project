package sample;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class LoginController {

    @FXML
    private PasswordField passwordText;

    @FXML
    private TextField userNameText;
    String username;
    String password;

public LoginController()
{
    userNameText=new TextField();
    passwordText=new PasswordField();
}


    public void LoginButtonClick(ActionEvent event){

        userNameText.setText("admin");
        passwordText.setText("admin");
        username=userNameText.getText();
        password=passwordText.getText();

        if (username.equals("admin")&&password.equals("admin")){

            try {
                FXMLLoader fxmlLoader=new FXMLLoader(getClass().getResource("mainWindow.fxml"));
                Parent root1;
                root1 = (Parent) fxmlLoader.load();
                Stage stage=new Stage();
                stage.setTitle("Main Window");
                stage.setScene(new Scene(root1));
                stage.setResizable(false);
                stage.show();

            }catch (Exception e){
                e.printStackTrace();
            }
        }

    }


}
