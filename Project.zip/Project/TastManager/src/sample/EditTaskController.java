package sample;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class EditTaskController implements Initializable {
    @FXML
    private TextField textTitle;

    @FXML
    private TextField textType;

    @FXML
    private TextField textHours;

    @FXML
    private TextField textMinutes;

    ProgramController programController;
    Task task;
    String title;
    String type;
    String hours;
    String minutes;
    String query;
    Connection connection;
    Statement statement;

    public EditTaskController() {
        textTitle = new TextField();
        textType = new TextField();
        textHours = new TextField();
        textMinutes = new TextField();
        programController = new ProgramController();
        task = programController.getSelectionTask();
        textTitle.setText(task.getTitle());
        textType.setText(task.getType());
        textHours.setText(String.valueOf(task.getHours()));
        textMinutes.setText(String.valueOf(task.getMinutes()));
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        textTitle.setText(task.getTitle());
        textType.setText(task.getType());
        textHours.setText(String.valueOf(task.getHours()));
        textMinutes.setText(String.valueOf((task.getMinutes())));
        query="select * from TaskTable";
        try {
            connection= DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Elite\\Desktop\\TasksManagement.accdb");
            statement= connection.createStatement();
            ResultSet resultSet=statement.executeQuery(query);
            while (resultSet.next()){
                programController.addTask(resultSet.getString("Title"),resultSet.getString("Type"),resultSet.getInt("Hours"),resultSet.getInt("Minutes"));
            }
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void editMethod(ActionEvent event) {
        {
            boolean edited = false;
            title = textTitle.getText();
            type = textType.getText();
            hours = textHours.getText();
            minutes = textMinutes.getText();
            String preTitle=task.getTitle();
            if (!task.getTitle().equals(title)) {
                edited = programController.editTitle(task,title);
                if (edited) {
                    query = "UPDATE TaskTable SET TaskTable.[Title] = \"" + title + "\" where TaskTable.Title=\"" + preTitle + "\";";
                    try {

                        connection = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Elite\\Desktop\\TasksManagement.accdb");
                        PreparedStatement preparedStatement = connection.prepareStatement(query);
                        preparedStatement.execute();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("Title has not been edited");
                    alert.showAndWait();
                }
            }
            if (!task.getType().equals(type)) {
                edited = programController.editType(task, type);
                if (edited) {
                    query = "UPDATE TaskTable SET TaskTable.[Type] = \"" + type + "\" where TaskTable.Title=\"" + task.getTitle() + "\";";
                    try {
                        connection = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Elite\\Desktop\\TasksManagement.accdb");
                        PreparedStatement preparedStatement = connection.prepareStatement(query);
                        preparedStatement.execute();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("Type has not been edited");
                    alert.showAndWait();
                }
            }
            if (task.getHours() != Integer.parseInt(hours)) {
                edited = programController.editType(task, hours);
                if (edited) {
                    query = "UPDATE TaskTable SET TaskTable.[Hours] = \"" + hours + "\" where TaskTable.Title=\"" + task.getTitle() + "\";";
                    try {
                        connection = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Elite\\Desktop\\TasksManagement.accdb");
                        PreparedStatement preparedStatement = connection.prepareStatement(query);
                        preparedStatement.execute();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("Hours have not been edited");
                    alert.showAndWait();
                }
            }
            if (task.getMinutes() != Integer.parseInt(minutes)) {
                edited = programController.editType(task, minutes);
                if (edited) {
                    query = "UPDATE TaskTable SET TaskTable.[Minutes] = \"" + minutes + "\" where TaskTable.Title=\"" + task.getTitle() + "\";";
                    try {
                        connection = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Elite\\Desktop\\TasksManagement.accdb");
                        PreparedStatement preparedStatement = connection.prepareStatement(query);
                        preparedStatement.execute();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("Minutes have not been edited");
                    alert.showAndWait();
                }
            }
            if (edited) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText(null);
                alert.setContentText("successfully edited");
                alert.showAndWait();
            }

        }
    }
}