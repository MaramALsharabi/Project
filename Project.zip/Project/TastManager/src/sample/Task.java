package sample;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
public class Task {
    private SimpleStringProperty title;
    private SimpleStringProperty type;
    protected SimpleIntegerProperty hours;
    protected SimpleIntegerProperty minutes;
    protected SimpleIntegerProperty seconds;
    public Task(String title, String type, int hours, int minutes) {
        this.title =new SimpleStringProperty(title);
        this.type = new SimpleStringProperty(type);
        this.hours = new SimpleIntegerProperty(hours);
        this.minutes = new SimpleIntegerProperty(minutes);
        this.seconds=new SimpleIntegerProperty(0);
    }

    protected Task(int hours, int minutes) {
        this.hours = new SimpleIntegerProperty(hours);
        this.minutes = new SimpleIntegerProperty(minutes);
        this.seconds=new SimpleIntegerProperty(0);

    }

    public String getTitle() {
        return title.get();
    }

    public void setTitle(String title) {
        this.title = new SimpleStringProperty(title);
    }

    public String getType() {
        return type.get();
    }

    public void setType(String type) {
        this.type = new SimpleStringProperty(type);
    }
    public int getHours()
    {
        return hours.get();
    }
    public void setHours(int hours)
    {
        this.hours=new SimpleIntegerProperty(hours);
    }
    public int getMinutes()
    {
        return minutes.get();
    }
    public void setMinutes(int minutes)
    {
        this.minutes=new SimpleIntegerProperty(minutes);
    }

    public int getSeconds() {
        return seconds.get();
    }

    public void setSeconds(int seconds) {
        this.seconds=new SimpleIntegerProperty(seconds);
    }

    @Override
    public String toString() {
        return "Task{" +
                "title=" + title +
                ", type=" + type +
                ", hours=" + hours +
                ", minutes=" + minutes +
                '}';
    }
}